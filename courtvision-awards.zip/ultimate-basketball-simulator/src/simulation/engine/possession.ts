import type { Attributes, PlayerId, PositionSuitability, RoleTendencies, PassingTendencies } from '../types';
import type { AggregatedFlags } from './effective';
import type { RNG } from './rng';
import { chooseBallHandler, computeBlockProbability, type BallHandlerCandidate } from './ballHandler';
import { chooseShotType, rollContestLevel, resolveShot, resolveFreeThrow, foulDrawProbability, andOneProbability, THREE_POINT_TYPES, type ShotType } from './shot';
import { resolveTurnover, type TurnoverContext } from './turnover';
import { resolveRebound, type RebounderCandidate } from './rebound';
import type { PlayerStatLine } from '../boxscore';
import type { FatigueState } from './fatigue';
import { fatiguePenaltyMultiplier } from './fatigue';
import { NEUTRAL_RULE_MODS, type RuleMods } from './ruleMods';

export interface OnCourtPlayer {
  playerId: PlayerId;
  attributes: Attributes;
  positions: PositionSuitability;
  flags: AggregatedFlags;
  ballHandlerPriority: number;
  role: RoleTendencies;
  shotTendencies: Record<ShotType, number>;
  ballDominance: number;
  passing: PassingTendencies;
  threePointTarget?: number; // explicit user override, engine must respect it
  fatigue: FatigueState;
}

export interface PossessionInput {
  offense: OnCourtPlayer[]; // 5 players
  defense: OnCourtPlayer[]; // 5 players
  matchups: number[]; // for each offense index, the defense index assigned as primary defender (position-weighted, see matchups.ts)
  quarter: number;
  clockSeconds: number;
  isClutch: boolean;
  isPlayoffs: boolean;
  shootingVariance: number;
  turnoverFrequencyMultiplier: number;
  foulFrequencyMultiplier: number;
  doubleTeamProbability: number; // derived from coach aggression + ball dominance
  offenseTeamId: string;
  rng: RNG;
  ruleMods?: RuleMods; // League Rules multipliers - omitted entirely => identical to pre-League-Rules behavior
}

export interface PossessionResult {
  ballHandlerId: PlayerId;
  events: string[];
  result: 'MAKE' | 'MISS' | 'TURNOVER' | 'FOUL';
  statDeltas: Record<PlayerId, Partial<PlayerStatLine>>;
  debug: Record<string, unknown>;
  pointsScored: number;
}

type Action = 'isolation' | 'pnr' | 'postUp' | 'drive' | 'catchAndShoot' | 'transition';

function chooseAction(bh: OnCourtPlayer, rng: RNG, mods: RuleMods): Action {
  const weights: [Action, number][] = [
    ['isolation', bh.role.isolation * mods.action.isolation],
    ['pnr', bh.role.pnrBallHandler * mods.action.pnr],
    ['postUp', bh.role.postUp * mods.action.postUp],
    ['drive', bh.role.primaryBallHandler * 0.5 + 10],
    ['catchAndShoot', bh.role.spotUpShooter + bh.role.catchAndShoot],
    ['transition', bh.role.transitionFinisher * 0.5 * mods.action.transition],
  ];
  const idx = rng.weightedPick(weights.map(([, w]) => Math.max(1, w)));
  return weights[idx][0];
}

function addDelta(deltas: Record<PlayerId, Partial<PlayerStatLine>>, id: PlayerId, patch: Partial<PlayerStatLine>) {
  const existing = deltas[id] ?? {};
  // for…in over a plain object literal: same keys and order as Object.entries, without allocating pairs.
  for (const k in patch) {
    const v = (patch as any)[k];
    if (typeof v === 'number') {
      (existing as any)[k] = ((existing as any)[k] ?? 0) + v;
    }
  }
  deltas[id] = existing;
}

/** Adjusts raw shot-type tendency weights so an explicit target-3PA override is respected over many possessions. */
function applyThreePointOverride(weights: Record<ShotType, number>, target: number | undefined): Record<ShotType, number> {
  if (target == null) return weights;
  const boosted = { ...weights };
  for (const t of THREE_POINT_TYPES) {
    boosted[t] = (boosted[t] ?? 1) * (1 + target / 8); // heavier explicit target => heavier three-weight
  }
  return boosted;
}

export function simulatePossession(input: PossessionInput): PossessionResult {
  const { rng, offense, defense } = input;
  const mods = input.ruleMods ?? NEUTRAL_RULE_MODS;
  const events: string[] = [];
  const statDeltas: Record<PlayerId, Partial<PlayerStatLine>> = {};

  const bhCandidates: BallHandlerCandidate[] = offense.map((p) => ({
    playerId: p.playerId,
    priority: p.ballHandlerPriority,
    fatigueLevel: p.fatigue.level,
    onCourt: true,
  }));
  const ballHandlerId = chooseBallHandler(bhCandidates, rng);
  const bh = offense.find((p) => p.playerId === ballHandlerId)!;
  const bhIndex = offense.indexOf(bh);
  const primaryDefender = defense[input.matchups[bhIndex]] ?? defense[0];

  addDelta(statDeltas, bh.playerId, { touches: 1 });
  events.push(`${bh.playerId} has the ball`);

  const action = chooseAction(bh, rng, mods);
  const doubleTeamed = rng.chance(input.doubleTeamProbability * mods.doubleTeamFrequency * (bh.ballDominance / 100));
  if (doubleTeamed) events.push('Double team');

  // --- Decision: pass (leading to a teammate's shot) vs shoot-it-yourself vs turn it over on the handle ---
  // Driven by the ball handler's own passing dial + playmaking IQ, tempered by how shot-hungry their
  // role/usage is. Real offenses route the large majority of possessions through at least one purposeful
  // pass before the shot goes up, so the baseline here sits well above a coin flip.
  const passTend = bh.passing?.passFrequency ?? 50;
  const playmakingIQ = (bh.attributes.offense.passingIQ + bh.attributes.offense.offensiveIQ + bh.attributes.offense.decisionMaking) / 3;
  let passFrequency = 48 + passTend * 0.42 + (playmakingIQ - 50) * 0.2;
  if (action === 'isolation' || action === 'postUp') passFrequency -= 14;
  if (action === 'pnr' || action === 'drive') passFrequency += 8;
  if (action === 'catchAndShoot') passFrequency -= 6; // they already got theirs off a prior pass; less likely to move it again
  passFrequency -= Math.max(0, bh.ballDominance - 60) * 0.35; // go-to scorers still shoot it themselves more often
  if (doubleTeamed) passFrequency += 20; // giving it up under pressure is the smart read
  passFrequency = Math.max(12, Math.min(90, passFrequency));
  const willPass = rng.chance(passFrequency / 100) && offense.length > 1;

  const turnoverCtx: TurnoverContext = {
    action: action === 'pnr' ? 'pnrHandle' : action === 'postUp' ? 'postUp' : action === 'catchAndShoot' ? 'catchAndShoot' : action === 'transition' ? 'transition' : willPass ? 'pass' : 'drive',
    isPass: willPass,
    defenderPerimeterDefense: primaryDefender.attributes.defense.perimeterDefense,
    defenderStealIQ: primaryDefender.attributes.defense.stealIQ,
    defenderOnBallSteal: primaryDefender.attributes.defense.onBallSteal,
    defenderPassingLaneSteal: primaryDefender.attributes.defense.passingLaneSteal,
    defensivePressure: doubleTeamed ? 0.6 : 0.15,
    doubleTeamed,
    fatigueLevel: bh.fatigue.level,
    turnoverFrequencyMultiplier: input.turnoverFrequencyMultiplier,
    stealFrequencyMultiplier: mods.turnover.stealFrequency * mods.turnover.stealSuccess,
    chargeFrequencyMultiplier: mods.turnover.chargeFrequency,
    perimeterDefenseImpactMultiplier: mods.turnover.perimeterDefenseImpact,
  };

  const tov = resolveTurnover(bh.attributes, turnoverCtx, bh.flags, rng);
  if (tov.occurred) {
    events.push(`Turnover: ${tov.type}`);
    addDelta(statDeltas, bh.playerId, { tov: 1, [`turnoverBreakdown.${tov.type}` as any]: 1 });
    if (tov.causedBySteal) {
      const stealer = tov.stealerCredit === 'ON_BALL' ? primaryDefender : defense[rng.nextInt(defense.length)];
      addDelta(statDeltas, stealer.playerId, { stl: 1 });
      events.push(`${stealer.playerId} STEAL`);
    }
    return { ballHandlerId: bh.playerId, events, result: 'TURNOVER', statDeltas, pointsScored: 0, debug: { turnoverProbability: tov.probability, action } };
  }

  // Determine who actually shoots (could be a teammate if a pass went out).
  let shooter = bh;
  let assistCandidate: OnCourtPlayer | null = null;
  if (willPass) {
    const teammates = offense.filter((p) => p.playerId !== bh.playerId);
    const weights = teammates.map((p) => {
      const defenderIdx = input.matchups[offense.indexOf(p)];
      const defender = defense[defenderIdx];
      // Lower defender contest/closeout = more "open" = more likely to be the pass target.
      const openness = defender ? Math.max(5, 100 - (defender.attributes.defense.contest + defender.attributes.defense.closeout) / 2) : 40;
      return 1 + p.role.spotUpShooter * 0.35 + p.role.catchAndShoot * 0.35 + p.role.cutter * 0.15 + openness * 0.5;
    });
    shooter = teammates[rng.weightedPick(weights)];
    assistCandidate = bh;
    events.push(`Pass to ${shooter.playerId}`);
  }
  const shooterDefender = defense[input.matchups[offense.indexOf(shooter)]] ?? primaryDefender;

  const rawShotWeights = shooter.shotTendencies;
  const adjustedShotWeights = applyThreePointOverride(rawShotWeights, shooter.threePointTarget);
  const shotType = chooseShotType(adjustedShotWeights as any, shooter.attributes.offense, rng, mods.shotTypeWeight);
  const isThree = THREE_POINT_TYPES.includes(shotType);

  const contest = rollContestLevel(
    shooterDefender.attributes.defense.contest, shooterDefender.attributes.defense.closeout, rng,
    mods.shot.contestEffectiveness, mods.shot.closeoutEffectiveness, mods.shot.heavilyContestedShotFrequency,
  );

  // Block check happens before the make/miss roll for rim-area shots.
  const blockProb = computeBlockProbability(
    shooterDefender.attributes, shotType, shooter.attributes.offense.finishing, shooterDefender.flags,
    mods.blockFrequency * mods.blockSuccess, mods.rimProtection,
  );
  addDelta(statDeltas, shooterDefender.playerId, { blkAtt: 1 });
  if (rng.chance(blockProb)) {
    events.push(`${shooterDefender.playerId} BLOCK`);
    addDelta(statDeltas, shooterDefender.playerId, { blk: 1 });
    addDelta(statDeltas, shooter.playerId, {
      fga: 1,
      tpa: isThree ? 1 : 0,
      rimAttempts: isThree ? 0 : 1,
      possessionsUsed: 1,
      ba: 1,
    });
    const reboundWinner = resolveReboundStep(offense, defense, isThree, rng, statDeltas, mods);
    const offensiveRebound = offense.some(p => p.playerId === reboundWinner);
    events.push(`Rebound: ${reboundWinner}`);
    if (offensiveRebound) events.push(`Offensive rebound: ${reboundWinner} keeps it alive`);
    return { ballHandlerId: bh.playerId, events, result: 'MISS', statDeltas, pointsScored: 0, debug: { blockProbability: blockProb, shotType, offensiveRebound } };
  }

  // Shooting foul check: a foul here sends the shooter to the line without the shot counting
  // as a field goal attempt, matching real basketball scoring rules.
  const foulProb = foulDrawProbability(shotType, contest, shooterDefender.attributes.mental.discipline, input.foulFrequencyMultiplier, mods.freeThrowFrequency);
  if (rng.chance(foulProb)) {
    addDelta(statDeltas, shooterDefender.playerId, { pf: 1 });
    const ftAttempts = isThree ? 3 : 2;
    let ftMakes = 0;
    const freeThrowOutcomes: boolean[] = [];
    for (let i = 0; i < ftAttempts; i++) {
      const made = resolveFreeThrow(shooter.attributes.offense.freeThrow, rng, mods.shot.freeThrowDifficulty);
      freeThrowOutcomes.push(made);
      if (made) ftMakes++;
    }
    addDelta(statDeltas, shooter.playerId, { fta: ftAttempts, ftm: ftMakes, points: ftMakes, possessionsUsed: 1, clutchPoints: input.isClutch ? ftMakes : 0 });
    events.push(`${shooterDefender.playerId} shooting foul on ${shooter.playerId} (${ftMakes}/${ftAttempts} FT)`);
    return { ballHandlerId: bh.playerId, events, result: 'FOUL', statDeltas, pointsScored: ftMakes, debug: { foulProbability: foulProb, shotType, contest, freeThrowOutcomes } };
  }

  const fatigueMult = fatiguePenaltyMultiplier(shooter.fatigue, shooter.flags);
  const effectiveAttrsForShot: Attributes = JSON.parse(JSON.stringify(shooter.attributes));
  // apply fatigue multiplicatively to the offensive block only (defense/mental untouched for shot math)
  (Object.keys(effectiveAttrsForShot.offense) as (keyof typeof effectiveAttrsForShot.offense)[]).forEach((k) => {
    if (typeof effectiveAttrsForShot.offense[k] === 'number') {
      (effectiveAttrsForShot.offense as any)[k] = (effectiveAttrsForShot.offense[k] as number) * fatigueMult;
    }
  });

  const shotResult = resolveShot(
    effectiveAttrsForShot,
    {
      type: shotType, contest, fatigueLevel: shooter.fatigue.level, isClutch: input.isClutch, isPlayoffs: input.isPlayoffs,
      shootingVariance: input.shootingVariance, action, wasAssisted: assistCandidate != null,
      defenderDefensiveIQ: shooterDefender.attributes.defense.defensiveIQ, ruleMods: mods.shot,
    },
    shooter.flags,
    rng,
  );

  addDelta(statDeltas, shooter.playerId, {
    fga: 1,
    tpa: isThree ? 1 : 0,
    possessionsUsed: 1,
  });

  if (shotResult.made) {
    let points = isThree ? 3 : 2;
    const freeThrowOutcomes: boolean[] = [];
    events.push(`${shooter.playerId} ${shotType} MAKE (+${points})`);
    addDelta(statDeltas, shooter.playerId, { points, fgm: 1, tpm: isThree ? 1 : 0, clutchPoints: input.isClutch ? points : 0 });

    // And-1: made shot despite contact draws the foul for a bonus free throw.
    if (rng.chance(andOneProbability(shotType, contest))) {
      addDelta(statDeltas, shooterDefender.playerId, { pf: 1 });
      const bonusMade = resolveFreeThrow(shooter.attributes.offense.freeThrow, rng, mods.shot.freeThrowDifficulty);
      freeThrowOutcomes.push(bonusMade);
      addDelta(statDeltas, shooter.playerId, { fta: 1, ftm: bonusMade ? 1 : 0, points: bonusMade ? 1 : 0 });
      if (bonusMade) points += 1;
      events.push(`${shooter.playerId} AND-1 (${bonusMade ? 'made' : 'missed'} FT)`);
    }

    if (assistCandidate) {
      const assistChance = Math.min(0.92, (0.55 + assistCandidate.attributes.offense.passingIQ * 0.005 + assistCandidate.role.primaryBallHandler * 0.0012) * mods.assistFrequency);
      if (assistCandidate.flags.automaticAssist || rng.chance(assistChance)) {
        addDelta(statDeltas, assistCandidate.playerId, { ast: 1 });
        events.push(`${assistCandidate.playerId} AST`);
      }
    }
    return { ballHandlerId: bh.playerId, events, result: 'MAKE', statDeltas, pointsScored: points, debug: { makeProbability: shotResult.probability, shotType, contest, freeThrowOutcomes } };
  }

  events.push(`${shooter.playerId} ${shotType} MISS`);
  const reboundWinner = resolveReboundStep(offense, defense, isThree, rng, statDeltas, mods);
  const offensiveRebound = offense.some(p => p.playerId === reboundWinner);
  events.push(`Rebound: ${reboundWinner}`);
  if (offensiveRebound) events.push(`Offensive rebound: ${reboundWinner} keeps it alive`);
  return { ballHandlerId: bh.playerId, events, result: 'MISS', statDeltas, pointsScored: 0, debug: { makeProbability: shotResult.probability, shotType, contest, offensiveRebound } };
}

function resolveReboundStep(
  offense: OnCourtPlayer[],
  defense: OnCourtPlayer[],
  wasThree: boolean,
  rng: RNG,
  statDeltas: Record<PlayerId, Partial<PlayerStatLine>>,
  mods: RuleMods,
): PlayerId {
  const candidates: RebounderCandidate[] = [
    ...offense.map((p) => ({ playerId: p.playerId, attributes: p.attributes, flags: p.flags, isOffense: true })),
    ...defense.map((p) => ({ playerId: p.playerId, attributes: p.attributes, flags: p.flags, isOffense: false })),
  ];
  const winnerId = resolveRebound(candidates, wasThree, rng, mods.reboundOffense, mods.reboundDefense);
  const winnerIsOffense = offense.some((p) => p.playerId === winnerId);
  addDelta(statDeltas, winnerId, winnerIsOffense ? { oreb: 1 } : { dreb: 1 });
  return winnerId;
}
