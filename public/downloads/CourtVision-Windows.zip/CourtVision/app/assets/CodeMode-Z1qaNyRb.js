import{r as e,t}from"./react-CbYonmBs.js";var n=e();function r(e,t){let n=JSON.parse(JSON.stringify(e)),r=[],i={log:(...e)=>r.push(e.map(e=>typeof e==`object`?JSON.stringify(e):String(e)).join(` `))};try{return Function(`player`,`console`,t)(n,i),{season:n,logs:r,error:null}}catch(t){return{season:e,logs:r,error:t instanceof Error?t.message:String(t)}}}var i=[{label:`Elite three-point shooter`,code:`player.attributes.offense.threePoint = 110;
player.attributes.offense.corner3 = 108;
player.attributes.offense.aboveBreak3 = 110;
player.attributes.offense.catchAndShoot = 105;
player.tendencies.threePointTargets = { target: 20 };
console.log('Updated 3PT profile for', player.playerId);`},{label:`Never Turnover + Primary Ball Handler`,code:`player.badges.push('never_turnover');
player.ballHandlerPriority = 95;
player.tendencies.ballDominance = 90;`},{label:`Conditional edit based on current rating`,code:`if (player.attributes.offense.ballHandling > 90) {
  player.attributes.offense.speedWithBall += 10;
  console.log('Bonus applied: elite handler gets a speed-with-ball boost');
} else {
  console.log('No bonus - ball handling below threshold');
}`},{label:`Exact minutes, 9 per quarter`,code:`player.minutes = {
  mode: 'EXACT',
  target: 36,
  perQuarter: [9, 9, 9, 9],
};`}],a=`Available on the 'player' object (same shape as the visual editor):

  player.attributes.physical.{heightInches, weightLbs, speed, vertical, ...}
  player.attributes.offense.{threePoint, ballHandling, ballSecurity, passing, finishing, ...}
  player.attributes.defense.{perimeterDefense, block, steal, rimProtection, ...}
  player.attributes.mental.{clutch, playoffPerformance, consistency, ...}
  player.positions.{PG, SG, SF, PF, C}                     0-100 suitability each
  player.tendencies.shot.{corner3, aboveBreak3, pullUp3, rim, midrange, ...}
  player.tendencies.passing.{passFrequency, assistCreation, riskyPass, ...}
  player.tendencies.driving.{driveFrequency, attackCloseout, ...}
  player.tendencies.role.{primaryBallHandler, isolation, postUp, spotUpShooter, ...}
  player.tendencies.ballDominance                          0-100
  player.tendencies.threePointTargets = { target, min, max }
  player.minutes = { mode: 'AI'|'TARGET'|'EXACT'|'MANUAL', target, perQuarter: [q1,q2,q3,q4] }
  player.badges                                            array of badge id strings, e.g. push('perfect_shooter')
  player.development.{potential, developmentRate, peakAge, ...}
  player.overall = { mode: 'AUTO'|'MANUAL', manualOverall }
  player.ballHandlerPriority                                0-100

Ratings go 0-99 in Realistic mode, 0-200+ in Sandbox mode (turn on Sandbox
Mode in the top bar for values above 99 to actually take effect in simulation).

console.log(...) is captured and shown below after Run.`,o=t();function s({season:e,onChange:t}){let[s,c]=(0,n.useState)(i[0].code),[l,u]=(0,n.useState)([]),[d,f]=(0,n.useState)(null),[p,m]=(0,n.useState)([]);return(0,o.jsxs)(`div`,{className:`code-mode`,children:[(0,o.jsxs)(`div`,{className:`code-mode-main`,children:[(0,o.jsxs)(`h4`,{children:[`Code Mode — `,e.playerId]}),(0,o.jsx)(`textarea`,{className:`code-editor`,value:s,spellCheck:!1,onChange:e=>c(e.target.value),rows:14}),(0,o.jsxs)(`div`,{className:`code-mode-actions`,children:[(0,o.jsx)(`button`,{className:`primary`,onClick:()=>{let n=r(e,s);u(n.logs),f(n.error),n.error||(m(t=>[...t,e]),t(n.season))},children:`Run`}),(0,o.jsx)(`button`,{disabled:p.length===0,onClick:()=>{let e=p[p.length-1];e&&(t(e),m(e=>e.slice(0,-1)))},children:`Undo`}),(0,o.jsxs)(`select`,{onChange:e=>c(i[Number(e.target.value)].code),defaultValue:``,children:[(0,o.jsx)(`option`,{value:``,disabled:!0,children:`Load example…`}),i.map((e,t)=>(0,o.jsx)(`option`,{value:t,children:e.label},e.label))]})]}),d&&(0,o.jsx)(`pre`,{className:`code-error`,children:d}),l.length>0&&(0,o.jsx)(`div`,{className:`code-console`,children:l.map((e,t)=>(0,o.jsxs)(`div`,{children:[`>`,` `,e]},t))}),(0,o.jsx)(`p`,{className:`hint-text`,children:`Changes apply to the same player data the visual editor uses — switch to Player Editor to see (or continue adjusting) the result of this script.`})]}),(0,o.jsx)(`pre`,{className:`code-docs`,children:a})]})}export{s as CodeMode};